**EtherCard** is a driver for the ENC28J60 chip, compatible with Arduino IDE.

Adapted and extended from code written by Guido Socher and Pascal Stang.

The home page for this library is at <http://jeelabs.net/projects/ethercard/wiki>.

License: GPL2

> Note: the issue tracker has been migrated to [Redmine on JeeLabs.net][1].

[1]: http://jeelabs.net/projects/development/issues?query_id=11
